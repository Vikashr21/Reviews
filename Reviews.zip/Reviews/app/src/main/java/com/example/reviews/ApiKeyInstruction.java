package com.example.reviews;

public class ApiKeyInstruction {


// For Movies and Tvshows Use TheMovieDB Api


    //For Music Use LastFm Api








}



